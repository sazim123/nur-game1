package com.nurgame.app

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.webkit.*
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

@SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
class MainActivity : ComponentActivity() {
    private lateinit var root: FrameLayout
    private lateinit var ui: WebView
    private var game: WebView? = null
    private var playing = false
    private var lastBack = 0L
    private val dir by lazy { File(filesDir, "games").apply { mkdirs() } }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importGame(uri)
    }

    inner class Bridge {
        @JavascriptInterface fun add() = runOnUiThread { picker.launch(arrayOf("*/*")) }
        @JavascriptInterface fun link(k: String) = runOnUiThread {
            val url = when (k) {
                "fb" -> "https://www.facebook.com/Nur01753507636"
                "tt" -> "https://www.tiktok.com/@nur01309232224"
                else -> return@runOnUiThread
            }
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { toast("লিংক খোলা যায়নি") }
        }
        @JavascriptInterface fun play(id: String) = runOnUiThread { start(id.filter { it.isLetterOrDigit() }) }
        @JavascriptInterface fun remove(id: String) = runOnUiThread {
            val k = id.filter { it.isLetterOrDigit() }
            File(dir, "$k.html").delete()
            WebStorage.getInstance().deleteOrigin("https://x$k.nurgame.app")
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 28)
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        root = FrameLayout(this)
        ui = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#08141B"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.textZoom = 100
            settings.mediaPlaybackRequiresUserGesture = false
            webChromeClient = WebChromeClient()
            addJavascriptInterface(Bridge(), "Nur")
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(ui, MATCH_PARENT, MATCH_PARENT)
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!playing) { finish(); return }
                val now = System.currentTimeMillis()
                if (now - lastBack < 2000) stop() else {
                    lastBack = now
                    toast("হোমে ফিরতে আবার Back চাপুন")
                }
            }
        })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun js(code: String) = ui.evaluateJavascript(code, null)

    private fun importGame(uri: Uri) {
        Thread {
            try {
                val name = contentResolver.query(uri, null, null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                } ?: "game.html"
                val low = name.lowercase()
                if (!(low.endsWith(".html") || low.endsWith(".htm"))) {
                    runOnUiThread { toast("শুধু .html ফাইল যোগ করা যাবে") }
                    return@Thread
                }
                val id = java.lang.Long.toString(System.currentTimeMillis(), 36)
                contentResolver.openInputStream(uri)!!.use { i ->
                    File(dir, "$id.html").outputStream().use { o -> i.copyTo(o, 1 shl 16) }
                }
                val title = name.substringBeforeLast('.').replace('_', ' ').replace('-', ' ')
                runOnUiThread { js("onAdded(${JSONObject.quote(id)},${JSONObject.quote(title)})") }
            } catch (e: Exception) {
                runOnUiThread { toast("ফাইল যোগ করা যায়নি") }
            }
        }.start()
    }

    private val cdn = setOf("cdnjs.cloudflare.com", "cdn.jsdelivr.net", "unpkg.com", "fonts.googleapis.com",
        "fonts.gstatic.com", "cdn.tailwindcss.com", "code.jquery.com", "ajax.googleapis.com",
        "stackpath.bootstrapcdn.com", "maxcdn.bootstrapcdn.com", "esm.sh", "cdn.skypack.dev")
    private val exts = listOf(".js", ".mjs", ".css", ".woff", ".woff2", ".ttf", ".otf", ".png", ".jpg", ".jpeg",
        ".gif", ".webp", ".svg", ".glb", ".gltf", ".bin", ".wasm")
    private val libs by lazy { File(filesDir, "libs").apply { mkdirs() } }

    // Libraries/fonts/images a game loads from the internet are saved on first use, then served offline forever.
    private fun cached(r: WebResourceRequest): WebResourceResponse? {
        val u = r.url
        val sch = u.scheme ?: return null
        if (r.method != "GET" || (sch != "http" && sch != "https")) return null
        val host = u.host ?: return null
        val p = (u.path ?: "").lowercase()
        if (host !in cdn && exts.none { p.endsWith(it) }) return null
        val key = MessageDigest.getInstance("SHA-1").digest(u.toString().toByteArray())
            .joinToString("") { "%02x".format(it) }
        val f = File(libs, key)
        val m = File(libs, "$key.m")
        try {
            if (!f.exists() || !m.exists()) {
                val c = URL(u.toString()).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 30000
                r.requestHeaders["User-Agent"]?.let { c.setRequestProperty("User-Agent", it) }
                if (c.responseCode != 200) return null
                val t = File(libs, "$key.tmp")
                c.inputStream.use { i -> t.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                m.writeText(c.contentType ?: "application/octet-stream")
                t.renameTo(f)
            }
            val ct = m.readText().split(";")
            val ext = p.substringAfterLast('.', "")
            val mime = ct[0].trim().let {
                if (it.isEmpty() || it == "application/octet-stream")
                    MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: it else it
            }
            val enc = ct.firstOrNull { it.contains("charset=") }?.substringAfter("=")?.trim()
            return WebResourceResponse(mime, enc, 200, "OK", mapOf("Access-Control-Allow-Origin" to "*"), f.inputStream())
        } catch (e: Exception) {
            return null
        }
    }

    private fun newGame(id: String) = WebView(this).apply {
        setBackgroundColor(Color.BLACK)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.setSupportZoom(false)
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
        var warned = false
        webChromeClient = WebChromeClient()
        // Each game gets its own origin (x<id>.nurgame.app) so saves never mix between games.
        webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (r.url.host != "x$id.nurgame.app") return cached(r)
                val f = File(dir, "$id.html")
                val p = r.url.path ?: "/"
                return if (f.exists() && (p == "/" || p == "/index.html"))
                    WebResourceResponse("text/html", "utf-8", f.inputStream())
                else WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            }
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                val h = r.url.host ?: return
                if (!warned && h != "x$id.nurgame.app" && (h in cdn || (r.url.path ?: "").endsWith(".js"))) {
                    warned = true
                    toast("এই গেমের জন্য প্রথমবার ইন্টারনেট লাগবে ($h)")
                }
            }
            override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                stop(); toast("মেমরি কম থাকায় গেম বন্ধ হয়েছে"); return true
            }
        }
    }

    private fun start(id: String) {
        if (!File(dir, "$id.html").exists()) { toast("গেম ফাইল পাওয়া যায়নি"); return }
        val g = newGame(id)
        game = g
        root.addView(g, MATCH_PARENT, MATCH_PARENT)
        ui.visibility = View.GONE
        playing = true
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        immersive(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        g.loadUrl("https://x$id.nurgame.app/")
        g.requestFocus()
    }

    private fun stop() {
        val g = game
        if (g != null) {
            root.removeView(g)
            g.loadUrl("about:blank")
            ui.postDelayed({ g.destroy() }, 600)
        }
        game = null
        playing = false
        ui.visibility = View.VISIBLE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        immersive(false)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        js("onBack()")
    }

    private fun immersive(on: Boolean) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onPause() { super.onPause(); game?.onPause(); CookieManager.getInstance().flush() }
    override fun onResume() { super.onResume(); game?.onResume(); if (playing) immersive(true) }
    override fun onDestroy() { super.onDestroy(); ui.destroy(); game?.destroy() }
}
